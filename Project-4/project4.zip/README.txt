There are known problems with the server. If results do not show up, 
the drop down doesn't work, or there are errors with receiving empty data, etc. then try powering down the virtual machine and 
restarting it. Then run the html file again.
